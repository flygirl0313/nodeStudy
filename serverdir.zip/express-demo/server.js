const path = require('path')
const express = require('express');
const template = require('art-template');
const fs = require('fs');
//创建服务器
const app = express();
//端口
const port = 3000;
const uri = `http://localhost:${port}`;

//服务器资源
const filePath = '/root'
// const filePath = '/Users/sizhimeng/desktop/学习/nodeStudy/express-demo'

//处理请求
app.get('/dir.html', function (req, res) {
  fs.readFile('./template.html', function (err, data) {
    if (err) {
      return res.end('404 not found')
    }
    fs.readdir(filePath, function (err, files) {
      if (err) {
        return res.end('Can not find root dir.')
      }
      let filesArr = handleFilesData(files);
      //渲染模版
      tempStr = template.render(data.toString(), {
        dirName: 'root',
        filesArr: filesArr,
      })
      res.send(tempStr)
    })
  })
})

// 处理文件相关信息
function handleFilesData(files) {
  let filesArr = []
  files.forEach((filename, fileindex) => {
    var stat = fs.statSync(filename);
    var reg = new RegExp('-', 'g')
    let obj = {
      name: filename,
      size: stat.size,
      birthtime: stat.birthtime.toLocaleString().replace(reg, '/'), //创建时间
      mtime: stat.mtime.toLocaleString().replace(reg, '/'), // 最后一次修改时间
      isFile: stat.isFile(),
      isDirectory: stat.isDirectory()
    }
    filesArr.push(obj)
  })
  return filesArr
}


//监听端口 
app.listen(port, function (err) {
  if (err) {
    console.log(err);
    return;
  }
  console.log('> Listening at ' + uri + '\n')
})